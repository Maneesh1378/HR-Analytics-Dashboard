# HR Analytics Dashboard 📊

## 📌 Project Overview
This project analyzes employee attrition and workforce trends using Power BI.

## 🔍 Key Insights
- R&D department has the highest attrition (~56%)
- Employees aged 25–34 show maximum exits
- Low job satisfaction drives higher attrition
- Male employees contribute majority of attrition

## 🛠 Tools Used
- Power BI
- DAX
- Excel

## 📷 Dashboard Preview
![Dashboard](dashboard.png)